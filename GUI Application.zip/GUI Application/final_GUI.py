
#------------------ Libraries for UI ---------------------------------------------------------------
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication,QWidget, QInputDialog, QPushButton, QFileDialog , QLabel, QTextEdit,QLineEdit
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import QProcess, Qt

#------------------- Libraries for Model ------------------------------------------------------------
from keras.models import load_model
from numpy import load
from numpy import expand_dims
from numpy.random import randint
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras_contrib.layers.normalization.instancenormalization import InstanceNormalization
from PIL import Image
from matplotlib import pyplot

#------------------ Loading Trained Model Globally ----------------------------------------------------
cust = {'InstanceNormalization': InstanceNormalization}
model_AtoB = load_model('g_model_AtoB_005000.h5', cust, compile=False)
#------------------------------------------------------------------------------------------------------

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(830, 600)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("coding.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)
        MainWindow.setStyleSheet("background-color: rgb(49, 49, 49);")
        MainWindow.setIconSize(QtCore.QSize(38, 38))
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(30, 60, 361, 441))
        self.groupBox.setTitle("")
        self.groupBox.setObjectName("groupBox")
        self.open_Image = QtWidgets.QPushButton(self.groupBox)
        self.open_Image.setGeometry(QtCore.QRect(40, 360, 291, 61))
        self.open_Image.setMouseTracking(True)
        self.open_Image.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"font: 87 8pt \"Arial Black\";\n"
"selection-background-color: rgb(0, 170, 255);\n"
"border-radius: 15px; border: 3px groove gray;\n"
"border-style: outset;")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("photo(1).png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.open_Image.setIcon(icon1)
        self.open_Image.setIconSize(QtCore.QSize(38, 38))
        self.open_Image.setObjectName("open_Image")
        self.initial_Image = QtWidgets.QLabel(self.groupBox)
        self.initial_Image.setGeometry(QtCore.QRect(40, 30, 261, 261))
        self.initial_Image.setFrameShape(QtWidgets.QFrame.Box)
        self.initial_Image.setFrameShadow(QtWidgets.QFrame.Raised)
        self.initial_Image.setLineWidth(4)
        self.initial_Image.setText("")
        self.initial_Image.setScaledContents(True)
        self.initial_Image.setObjectName("initial_Image")
        self.groupBox_2 = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox_2.setGeometry(QtCore.QRect(430, 60, 361, 441))
        self.groupBox_2.setTitle("")
        self.groupBox_2.setObjectName("groupBox_2")
        self.dehaze_Image = QtWidgets.QPushButton(self.groupBox_2)
        self.dehaze_Image.setGeometry(QtCore.QRect(40, 360, 291, 61))
        self.dehaze_Image.setMouseTracking(True)
        self.dehaze_Image.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"font: 87 8pt \"Arial Black\";\n"
"selection-background-color: rgb(0, 170, 255);\n"
"border-radius: 15px; border: 3px groove gray;\n"
"border-style: outset;")
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("data.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.dehaze_Image.setIcon(icon2)
        self.dehaze_Image.setIconSize(QtCore.QSize(38, 38))
        self.dehaze_Image.setObjectName("dehaze_Image")
        self.dehazed_Image = QtWidgets.QLabel(self.groupBox_2)
        self.dehazed_Image.setGeometry(QtCore.QRect(50, 30, 261, 261))
        self.dehazed_Image.setFrameShape(QtWidgets.QFrame.Box)
        self.dehazed_Image.setFrameShadow(QtWidgets.QFrame.Raised)
        self.dehazed_Image.setLineWidth(4)
        self.dehazed_Image.setText("")
        self.dehazed_Image.setScaledContents(True)
        self.dehazed_Image.setObjectName("dehazed_Image")
        MainWindow.setCentralWidget(self.centralwidget)
       

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.open_Image.clicked.connect(self.browseImage)
        self.dehaze_Image.clicked.connect(self.dehazeImage)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Dehazing Application"))
        self.open_Image.setText(_translate("MainWindow", "Open An Image"))
        self.dehaze_Image.setText(_translate("MainWindow", "Dehaze"))

# ------------------ Function to Browse and Open Image ------------------------------------------
    def browseImage(self):
        self.fname = QFileDialog.getOpenFileName()
        self.imagePath = self.fname[0]
        print(self.imagePath)
        pixmap = QPixmap(self.imagePath) 
        self.initial_Image.setPixmap(QPixmap(self.imagePath))

# --------------- Converting the image into the Model Input Format ------------------------------
    def load_image(self, browseImage):
        # load and resize the image
        pixels = load_img(self.imagePath, target_size=(256,256))
        # convert to numpy array
        pixels = img_to_array(pixels)
        # transform in a sample
        pixels = expand_dims(pixels, 0)
        # scale from [0,255] to [-1,1]
        pixels = (pixels - 127.5) / 127.5
        return pixels

# -------------- Dehazing the Input Image and Saving it ---------------------------------------
    def dehazeImage(self, load_image):
        image_src = self.load_image(self.imagePath)
        image_tar = model_AtoB.predict(image_src)
        print('Predicted')
        image_tar = (image_tar[0] + 1) / 2.0
        #------------- Saving Image At Source Path---------------------------------------------
        str = self.imagePath
        array_fname =str.split('/')
        image_name = array_fname[len(array_fname)-1]
        split_fname =image_name.split('.')
        print(split_fname)
        final_image_name=''
        for i in range(len(split_fname)):
                if i<=len(split_fname)-2:
                        final_image_name += split_fname[i]
                else:
                        final_image_name +='dehazed.jpg'

        array_fname.pop()
        array_fname.append(final_image_name)
        save_dehazed = '/'.join(array_fname)
        #---------------------------------------------------------------------------------------
        pyplot.imsave(save_dehazed, image_tar)           #saving the image with correct filename
        pixmap2 = QPixmap(save_dehazed)                  #loading the image
        self.dehazed_Image.setPixmap(QPixmap(pixmap2))   #opening in label



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
